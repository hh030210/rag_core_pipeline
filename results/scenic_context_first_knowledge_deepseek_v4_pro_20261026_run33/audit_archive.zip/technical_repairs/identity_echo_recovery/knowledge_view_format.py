"""Only escape unescaped quotes inside completed, one-line JSON reasons."""
import hashlib
import json
import re


def canonicalize(original,expected_fields):
    try:json.loads(original);return original,None
    except json.JSONDecodeError:pass
    matches=list(re.finditer(r'(?m)^[ \t]*"reasoning"\s*:\s*"([^\r\n]*)"(?=[ \t]*\r?\n[ \t]*\})',original))
    if len(matches)!=len(expected_fields):raise ValueError('Not an unambiguous completed reason-line quote error')
    edits=[]
    for match in matches:
        body=match.group(1)
        for index,char in enumerate(body):
            if char!='"':continue
            backslashes=0;position=index-1
            while position>=0 and body[position]=='\\':backslashes+=1;position-=1
            if backslashes%2==0:edits.append({'offset':match.start(1)+index,'insert':'\\'})
    if not edits:raise ValueError('No safe quote-only repair')
    canonical=original
    for edit in sorted(edits,key=lambda value:value['offset'],reverse=True):canonical=canonical[:edit['offset']]+'\\'+canonical[edit['offset']:]
    value=json.loads(canonical)
    if not isinstance(value,dict) or set(value)!=set(expected_fields):raise ValueError('Quote repair changed object scope')
    return canonical,{'kind':'escape_only_unescaped_interior_reason_quotes','original_sha256':hashlib.sha256(original.encode()).hexdigest(),
        'canonical_sha256':hashlib.sha256(canonical.encode()).hexdigest(),'edits':edits,'no_score_or_word_edits':True}
